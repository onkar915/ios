//
//  widgetTests.swift
//  widgetTests
//
//  Created by Swarup Phatangare on 13/09/25.
//

import Testing
@testable import widget

struct widgetTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
