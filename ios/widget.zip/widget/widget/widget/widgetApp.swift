//
//  widgetApp.swift
//  widget
//
//  Created by Swarup Phatangare on 13/09/25.
//

import SwiftUI

@main
struct widgetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
